package data;

public class Puzzle {
	private String Photo1;
	private String Photo2;
	private String Photo3;
	private String PhotoName1;
	private String PhotoName2;
	private String PhotoName3;
	
	private String CityName;

	public String getPhoto1() {
		return Photo1;
	}

	public void setPhoto1(String photo1) {
		Photo1 = photo1;
	}

	public String getPhoto2() {
		return Photo2;
	}

	public void setPhoto2(String photo2) {
		Photo1 = photo2;
	}

	public String getPhoto3() {
		return Photo3;
	}

	public void setPhoto3(String photo3) {
		Photo1 = photo3;
	}

	public String getPhotoName1() {
		return PhotoName1;
	}

	public void setPhotoName1(String photoname1) {
		PhotoName1 = photoname1;
	}
	
	public String getPhotoName2() {
		return PhotoName2;
	}

	public void setPhotoName2(String photoname2) {
		PhotoName2 = photoname2;
	}
	
	public String getPhotoName3() {
		return PhotoName3;
	}

	public void setPhotoName3(String photoname3) {
		PhotoName3 = photoname3;
	}
		
	public String getCityName() {
		return CityName;
	}

	public void setCityName(String cityName) {
		CityName = cityName;
	}	
}

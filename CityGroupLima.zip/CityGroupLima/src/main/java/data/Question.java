package data;

public class Question {
	private String Question1;
	private String Question2;
	private String Question3;
	private String Question4;
	private String Question5;
	
	private String Image1;
	private String Image2;
	private String Image3;
	private String Image4;
	private String Image5;
	
	private String Choice11;
	private String Choice12;
	private String Choice13;
	private String Choice14;
	
	private String Choice21;
	private String Choice22;
	private String Choice23;
	private String Choice24;
	
	private String Choice31;
	private String Choice32;
	private String Choice33;
	private String Choice34;
	
	private String Choice41;
	private String Choice42;
	private String Choice43;
	private String Choice44;
	
	private String Choice51;
	private String Choice52;
	private String Choice53;
	private String Choice54;
	
	private String Correct1;
	private String Correct2;
	private String Correct3;
	private String Correct4;
	private String Correct5;
	
	private String CityName;

	public String getQuestion1() {
		return Question1;
	}

	public void setQuestion1(String question1) {
		Question1 = question1;
	}

	public String getQuestion2() {
		return Question2;
	}

	public void setQuestion2(String question2) {
		Question2 = question2;
	}

	public String getQuestion3() {
		return Question3;
	}

	public void setQuestion3(String question3) {
		Question3 = question3;
	}

	public String getQuestion4() {
		return Question4;
	}

	public void setQuestion4(String question4) {
		Question4 = question4;
	}

	public String getQuestion5() {
		return Question5;
	}

	public void setQuestion5(String question5) {
		Question5 = question5;
	}

	public String getImage1() {
		return Image1;
	}

	public void setImage1(String image1) {
		Image1 = image1;
	}

	public String getImage2() {
		return Image2;
	}

	public void setImage2(String image2) {
		Image2 = image2;
	}

	public String getImage3() {
		return Image3;
	}

	public void setImage3(String image3) {
		Image3 = image3;
	}

	public String getImage4() {
		return Image4;
	}

	public void setImage4(String image4) {
		Image4 = image4;
	}

	public String getImage5() {
		return Image5;
	}

	public void setImage5(String image5) {
		Image5 = image5;
	}

	public String getChoice11() {
		return Choice11;
	}

	public void setChoice11(String choice11) {
		Choice11 = choice11;
	}

	public String getChoice12() {
		return Choice12;
	}

	public void setChoice12(String choice12) {
		Choice12 = choice12;
	}

	public String getChoice13() {
		return Choice13;
	}

	public void setChoice13(String choice13) {
		Choice13 = choice13;
	}

	public String getChoice14() {
		return Choice14;
	}

	public void setChoice14(String choice14) {
		Choice14 = choice14;
	}

	public String getChoice21() {
		return Choice21;
	}

	public void setChoice21(String choice21) {
		Choice21 = choice21;
	}

	public String getChoice22() {
		return Choice22;
	}

	public void setChoice22(String choice22) {
		Choice22 = choice22;
	}

	public String getChoice23() {
		return Choice23;
	}

	public void setChoice23(String choice23) {
		Choice23 = choice23;
	}

	public String getChoice24() {
		return Choice24;
	}

	public void setChoice24(String choice24) {
		Choice24 = choice24;
	}

	public String getChoice31() {
		return Choice31;
	}

	public void setChoice31(String choice31) {
		Choice31 = choice31;
	}

	public String getChoice32() {
		return Choice32;
	}

	public void setChoice32(String choice32) {
		Choice32 = choice32;
	}

	public String getChoice33() {
		return Choice33;
	}

	public void setChoice33(String choice33) {
		Choice33 = choice33;
	}

	public String getChoice34() {
		return Choice34;
	}

	public void setChoice34(String choice34) {
		Choice34 = choice34;
	}

	public String getChoice41() {
		return Choice41;
	}

	public void setChoice41(String choice41) {
		Choice41 = choice41;
	}

	public String getChoice42() {
		return Choice42;
	}

	public void setChoice42(String choice42) {
		Choice42 = choice42;
	}

	public String getChoice43() {
		return Choice43;
	}

	public void setChoice43(String choice43) {
		Choice43 = choice43;
	}

	public String getChoice44() {
		return Choice44;
	}

	public void setChoice44(String choice44) {
		Choice44 = choice44;
	}

	public String getChoice51() {
		return Choice51;
	}

	public void setChoice51(String choice51) {
		Choice51 = choice51;
	}

	public String getChoice52() {
		return Choice52;
	}

	public void setChoice52(String choice52) {
		Choice52 = choice52;
	}

	public String getChoice53() {
		return Choice53;
	}

	public void setChoice53(String choice53) {
		Choice53 = choice53;
	}

	public String getChoice54() {
		return Choice54;
	}

	public void setChoice54(String choice54) {
		Choice54 = choice54;
	}

	public String getCorrect1() {
		return Correct1;
	}

	public void setCorrect1(String correct1) {
		Correct1 = correct1;
	}

	public String getCorrect2() {
		return Correct2;
	}

	public void setCorrect2(String correct2) {
		Correct2 = correct2;
	}

	public String getCorrect3() {
		return Correct3;
	}

	public void setCorrect3(String correct3) {
		Correct3 = correct3;
	}

	public String getCorrect4() {
		return Correct4;
	}

	public void setCorrect4(String correct4) {
		Correct4 = correct4;
	}

	public String getCorrect5() {
		return Correct5;
	}

	public void setCorrect5(String correct5) {
		Correct5 = correct5;
	}

	public String getCityName() {
		return CityName;
	}

	public void setCityName(String cityName) {
		CityName = cityName;
	}
	
	

	
	
}

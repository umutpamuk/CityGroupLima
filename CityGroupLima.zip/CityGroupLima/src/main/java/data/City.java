package data;

public class City {
	private String CityName;
	
	private String Carusel1;
	private String Carusel1Alt;
	private String Carusel1Back;
	
	private String Carusel2;
	private String Carusel2Alt;
	private String Carusel2Back;
	
	private String Carusel3;
	private String Carusel3Alt;
	private String Carusel3Back;

	private String Info;
	private String Info1;
	private String Info1Right;
	private String Info2;
	private String Info2Left;
	private String Info3;
	
	private String Img1;
	private String Img2;
	private String Img3;
	private String Img4;
	private String Img5;
	private String Img6;
	private String Img7;
	private String Img8;
	

	public String getImg1() {
		return Img1;
	}

	public void setImg1(String img1) {
		Img1 = img1;
	}

	public String getImg2() {
		return Img2;
	}

	public void setImg2(String img2) {
		Img2 = img2;
	}

	public String getImg3() {
		return Img3;
	}

	public void setImg3(String img3) {
		Img3 = img3;
	}

	public String getImg4() {
		return Img4;
	}

	public void setImg4(String img4) {
		Img4 = img4;
	}

	public String getImg5() {
		return Img5;
	}

	public void setImg5(String img5) {
		Img5 = img5;
	}

	public String getImg6() {
		return Img6;
	}

	public void setImg6(String img6) {
		Img6 = img6;
	}

	public String getImg7() {
		return Img7;
	}

	public void setImg7(String img7) {
		Img7 = img7;
	}

	public String getCityName() {
		return CityName;
	}

	public void setCityName(String cityName) {
		CityName = cityName;
	}

	public String getCarusel1() {
		return Carusel1;
	}

	public void setCarusel1(String carusel1) {
		Carusel1 = carusel1;
	}

	public String getCarusel1Alt() {
		return Carusel1Alt;
	}

	public void setCarusel1Alt(String carusel1Alt) {
		Carusel1Alt = carusel1Alt;
	}

	public String getCarusel1Back() {
		return Carusel1Back;
	}

	public void setCarusel1Back(String carusel1Back) {
		Carusel1Back = carusel1Back;
	}

	public String getCarusel2() {
		return Carusel2;
	}

	public void setCarusel2(String carusel2) {
		Carusel2 = carusel2;
	}

	public String getCarusel2Alt() {
		return Carusel2Alt;
	}

	public void setCarusel2Alt(String carusel2Alt) {
		Carusel2Alt = carusel2Alt;
	}

	public String getCarusel2Back() {
		return Carusel2Back;
	}

	public void setCarusel2Back(String carusel2Back) {
		Carusel2Back = carusel2Back;
	}

	public String getCarusel3() {
		return Carusel3;
	}

	public void setCarusel3(String carusel3) {
		Carusel3 = carusel3;
	}

	public String getCarusel3Alt() {
		return Carusel3Alt;
	}

	public void setCarusel3Alt(String carusel3Alt) {
		Carusel3Alt = carusel3Alt;
	}

	public String getCarusel3Back() {
		return Carusel3Back;
	}

	public void setCarusel3Back(String carusel3Back) {
		Carusel3Back = carusel3Back;
	}

	public String getInfo() {
		return Info;
	}

	public void setInfo(String info) {
		Info = info;
	}

	public String getInfo1() {
		return Info1;
	}

	public void setInfo1(String info1) {
		Info1 = info1;
	}

	public String getInfo1Right() {
		return Info1Right;
	}

	public void setInfo1Right(String info1Right) {
		Info1Right = info1Right;
	}

	public String getInfo2() {
		return Info2;
	}

	public void setInfo2(String info2) {
		Info2 = info2;
	}

	public String getInfo2Left() {
		return Info2Left;
	}

	public void setInfo2Left(String info2Left) {
		Info2Left = info2Left;
	}

	public String getInfo3() {
		return Info3;
	}

	public void setInfo3(String info3) {
		Info3 = info3;
	}

	public String getImg8() {
		return Img8;
	}

	public void setImg8(String img8) {
		Img8 = img8;
	}
}
